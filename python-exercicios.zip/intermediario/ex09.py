valor=int(input('Valor: '))
notas=[100,50,20,10,5]
for n in notas:
    q,valor=divmod(valor,n)
    print(n,':',q)
