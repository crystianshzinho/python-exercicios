frase=input('Frase: ').lower()
vogais='aeiou'
print(sum(frase.count(v) for v in vogais))
