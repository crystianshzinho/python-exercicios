nums=list(map(float,input('Números separados por espaço: ').split()))
print('Maior =', max(nums))
