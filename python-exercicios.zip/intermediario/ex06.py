p=input('Palavra: ').lower()
print('Palíndromo' if p==p[::-1] else 'Não é palíndromo')
