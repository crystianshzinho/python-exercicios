nome=input('Digite seu nome: ')
print(f'Bem-vindo, {nome}!')
