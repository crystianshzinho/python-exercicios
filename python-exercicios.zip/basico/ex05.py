c=float(input('Celsius: '))
f=c*9/5+32
print('Fahrenheit =',f)
