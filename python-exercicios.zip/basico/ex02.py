a=float(input('Digite o primeiro número: '))
b=float(input('Digite o segundo número: '))
print('Soma =', a+b)
