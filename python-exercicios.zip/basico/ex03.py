n=int(input('Número: '))
print('Par' if n%2==0 else 'Ímpar')
