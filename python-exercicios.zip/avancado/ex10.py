import random
seg=random.randint(1,100)
while True:
    pal=int(input('Adivinhe: '))
    if pal==seg:
        print('Acertou!')
        break
    print('Maior' if pal<seg else 'Menor')
