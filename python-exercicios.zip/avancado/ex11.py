import json
arq='contatos.json'
cont={'nome':input('Nome: '),'tel':input('Telefone: ')}
with open(arq,'w') as f: json.dump(cont,f)
print('Salvo!')
